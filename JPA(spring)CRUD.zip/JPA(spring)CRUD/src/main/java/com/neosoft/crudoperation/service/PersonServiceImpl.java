package com.neosoft.crudoperation.service;

import com.neosoft.crudoperation.controller.PersonController;
import com.neosoft.crudoperation.entity.Person;
import com.neosoft.crudoperation.repository.PersonRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class PersonServiceImpl implements PersonService {
    @Autowired
    PersonController personController;
    @Autowired
    PersonRepo personRepo;


    public Person updatePerson(@RequestBody Person person1, @PathVariable long id) {

        Person person = personRepo.findById(id).orElseThrow(() -> new RuntimeException("Does not exist"));
        person.setId(person1.getId());
        person.setName(person1.getName());
        person.setAge(person1.getAge());
        person.setGender(person1.getGender());
        personRepo.save(person);
        return person;
    }
}
