package com.neosoft.crudoperation.controller;

import com.neosoft.crudoperation.entity.Person;
import com.neosoft.crudoperation.repository.PersonRepo;
import com.neosoft.crudoperation.service.PersonServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/person")
public class PersonController {

    @Autowired
    PersonRepo personRepo;
    @Autowired
    private PersonServiceImpl personService;

    @PostMapping("/add")
    public Person addPerson(@RequestBody Person person) {
        return personRepo.save(person);
    }

    @GetMapping("/{id}")
    public Person getPersonById(@PathVariable long id) {
        return personRepo.findById(id).orElse(null);
    }

    @GetMapping("/findName/{id}")
    public String getPersonNameById(@PathVariable long id) {
        Person person = personRepo.findById(id).orElse(null);
        return person.getName();
    }

    @GetMapping("/all")
    public List<Person> getAllPerson() {
        return personRepo.findAll();
    }

    @PutMapping("/updateById/{id}")
    public Person updatePerson(@RequestBody Person person1, @PathVariable long id) throws ClassNotFoundException {
        if (person1 == null) {
            throw new ClassNotFoundException("Person not found");
        }
        Person person = personRepo.findById(id).orElseThrow(() -> new RuntimeException("Does not exist"));
        person.setId(person1.getId());
        person.setName(person1.getName());
        person.setAge(person1.getAge());
        person.setGender(person1.getGender());
        personRepo.save(person);
        return person;
    }

    @DeleteMapping("/deleteById/{id}")
    public void deletePerson(@PathVariable long id) {
        Person person = personRepo.findById(id).orElseThrow();
        personRepo.delete(person);
    }
}