package com.neosoft.crudoperation.service;

import com.neosoft.crudoperation.entity.Person;

public interface PersonService {
    public Person updatePerson(Person person, long id);

}
